//
//  BottomSheetApp.swift
//  BottomSheet
//
//  Created by Ahmed Atia on 05/08/2025.
//

import SwiftUI

@main
struct PocBottomSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ExampleView()
        }
    }
}
