// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "CoyoteBottomSheet",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(
            name: "CoyoteBottomSheet",
            targets: ["CoyoteBottomSheet"]
        ),
    ],
    targets: [
        .target(
            name: "CoyoteBottomSheet",
            path: "./Sources/BottomSheet"
        )
    ]
)
